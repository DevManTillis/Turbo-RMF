from __future__ import unicode_literals
from django.db import models



class Document(models.Model):
    document_name = models.CharField(max_length=200, default='NONE')
    document_owner = models.CharField(max_length=200, default='NONE')
    document_data = models.CharField(max_length=200)
    #document_location = models.CharField(max_length=200, default='NONE')
    document = models.FileField(upload_to='documents/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.document_name

    def __str__(self):
        return self.document_owner

    def __str__(self):
        return self.document_data
"""
"""
# Create your models here.
