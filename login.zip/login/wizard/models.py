from __future__ import unicode_literals
from django.db import models

# Create your models here.

class Document(models.Model):
    document_name = models.CharField(max_length=200, default='NONE')
    document_owner = models.CharField(max_length=200, default='NONE')
    document_data = models.CharField(max_length=200)
    document = models.FileField(upload_to='documents/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
##    v_ids = models.CharField(max_length=200, default='NONE')
##    v_sev = models.CharField(max_length=200, default='NONE')
##    v_dis = models.CharField(max_length=200, default='NONE')
##    v_con = models.CharField(max_length=200, default='NONE')
##    v_fix = models.CharField(max_length=200, default='NONE')
##    v_ref = models.CharField(max_length=200, default='NONE')
##    v_sta = models.CharField(max_length=200, default='NONE')
##    v_com = models.CharField(max_length=200, default='NONE')
##    v_det = models.CharField(max_length=200, default='NONE')
    def __str__(self):
        return self.document_name
    def __str__(self):
        return self.document_owner
    def __str__(self):
        return self.document_data
"""
"""

