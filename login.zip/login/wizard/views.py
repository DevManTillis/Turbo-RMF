from django.shortcuts import render
from django.shortcuts import get_object_or_404, render
from django.template import loader
from django.http import HttpResponseRedirect, HttpResponse
from django.urls import reverse
from django.views import generic
from django.utils import timezone

from django.shortcuts import render, redirect
from django.conf import settings
from django.core.files.storage import FileSystemStorage

from .models import Document
from .forms import DocumentForm


# Create your views here.
"""
def scanit():
    path = os.path.abspath('.\\vulnscan\VulnScan.ps1')
    #print(path)
    subprocess.Popen("cmd.exe")
    return str("bingo")
"""
def index(request):
    if request.user.is_authenticated:
        # Do something for authenticated users.
        context = "Authenticated!"
        return render(request, 'wizard/index.html', {'context': context})
    else:
        # Do something for anonymous users.
        context = "Sorry NOT Authed!"
        return render(request, 'wizard/index.html', {'context': context})
"""
def run(request):
    if request.user.is_authenticated:
        # Do something for authenticated users.
        
        context = scanit()
        return render(request, 'wizard/run.html', {'context': context})
    else:
        # Do something for anonymous users.
        context = "Sorry NOT Authed!"
        return render(request, 'wizard/run.html', {'context': context})


def run(request):
    documents = Document.objects.all()
    return render(request, 'wizard/home.html', { 'documents': documents })
"""

"""
Document.objects.all()
q = Document.objects.get(pk=1)
q.document_name
q.document_owner
q.document_data
"""

# FILE UPLOAD
def run(request):
    if request.method == 'POST' and request.FILES['myfile']:
        myfile = request.FILES['myfile']
        # PROCESS UPLOADED FILE
        # process_file(myfile)
        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        myfile.seek(0)
        doc_name = myfile.name
        doc_owner = request.user
        uploaded_file_url = fs.url(filename)
        # declare empty byte string
        data = b''
        chunks = myfile.chunks(chunk_size=None)
        for chunk in chunks:
            data += chunk
        # change byte file to UTF-8
        doc_data = str(data.decode(encoding='utf-8'))

        database_add = Document(document_name=doc_name,document_owner=doc_owner,document_data=doc_data)
        database_add.save()
        
        #documents = Document.objects.all()
        return render(request, 'wizard/simple_upload.html', {
            'uploaded_file_url': uploaded_file_url,
            'doc_data': doc_data,
            'doc_name': doc_name,
            'doc_owner': doc_owner
        })
    return render(request, 'wizard/simple_upload.html')

