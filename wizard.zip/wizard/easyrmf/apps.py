from django.apps import AppConfig


class EasyrmfConfig(AppConfig):
    name = 'easyrmf'
