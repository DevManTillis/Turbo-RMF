from django.apps import AppConfig


class WizardConfig(AppConfig):
    name = 'wizard'
