from django.db import models
import datetime
from django.utils import timezone



class Checklist(models.Model):
    checklist_text = models.CharField(max_length=200)
    pub_date = models.DateTimeField('date published')
    
    checklist_name = models.CharField(max_length=200)
    checklist_owner = models.CharField(max_length=200)
    def was_published_recently(self):
        return self.pub_date >= timezone.now() - datetime.timedelta(days=1)
    def __str__(self):
        return self.checklist_text




class Vuln(models.Model):
    checklist = models.ForeignKey(Checklist, on_delete=models.CASCADE)
    v_ids = models.CharField(max_length=200)
    vuln_text = models.CharField(max_length=200)
    votes = models.IntegerField(default=0)
    v_sev = models.CharField(max_length=200)
    v_dis = models.CharField(max_length=200)
    v_con = models.CharField(max_length=200)
    v_fix = models.CharField(max_length=200)
    v_ref = models.CharField(max_length=200)
    v_sta = models.CharField(max_length=200)
    v_com = models.CharField(max_length=200)
    v_det = models.CharField(max_length=200)
#        v_det = models.CharField(max_length=200, default='NONE')
    def __str__(self):
        return self.vuln_text
