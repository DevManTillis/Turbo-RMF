from django.contrib import admin


from .models import Checklist, Vuln

admin.site.register(Checklist)
admin.site.register(Vuln)
