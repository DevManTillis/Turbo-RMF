from django.conf.urls import url

from . import views

app_name = 'vulnscan'
urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^charts/$', views.charts, name='charts'),
    url(r'^tables/$', views.tables, name='tables'),
    url(r'^forms/$', views.forms, name='forms')
    #url(r'^RMF_Step1/$', views.RMF_Step1, name='RMF_Step1'),
]
