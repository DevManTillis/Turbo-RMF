from django.shortcuts import get_object_or_404, render
from django.template import loader
from django.http import HttpResponseRedirect, HttpResponse
#from .models import Question, Choice
from django.urls import reverse
from django.views import generic
import winreg
from django.utils import timezone

# Create your views here.
def index(request):
    form = "Hello World!"
    return render(request, 'vulnscan/index.html', {'form': form})

def charts(request):
    form = "Hello World!"
    return render(request, 'vulnscan/charts.html', {'form': form})

def tables(request):
    form = "Hello World!"
    return render(request, 'vulnscan/tables.html', {'form': form})

def forms(request):
    form = "Hello World!"
    return render(request, 'vulnscan/forms.html', {'form': form})
