from django.conf.urls import url

from . import views

app_name = 'categorize'
urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^RMF_Step1/$', views.RMF_Step1, name='RMF_Step1'),
]
