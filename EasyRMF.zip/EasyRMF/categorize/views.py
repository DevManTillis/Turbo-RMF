from django.shortcuts import get_object_or_404, render
from django.template import loader
# Create your views here.
from django.http import HttpResponseRedirect, HttpResponse
from .models import Question, Choice
from django.urls import reverse
from django.views import generic
import winreg
from django.utils import timezone
from .forms import CategorizeForm
from .categorize_form import *


# ListKey queries the registry
def ListKey(house,path,key):
    hKey = winreg.OpenKey(house, path)                                     
    result = winreg.QueryValueEx(hKey, key)
    winreg.CloseKey(hKey)
    return str(result[0])



def RMF_Step1(request):
    # if this is a POST request we need to process the form data
    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        form = CategorizeForm(request.POST)
        # check whether it's valid:
        if form.is_valid():
            information_system_name = form.cleaned_data['information_system_name']
            #contexttest = "Conditional Statement Test"
            context = {
                       'information_system_name': information_system_name,
                       'form': form
                       }
                       
            return render(request, 'categorize/contactform.html', context)
    else:
        form = CategorizeForm()
    return render(request, 'categorize/contactform.html', {'form': form})

"""
"""

def index(request):
    form = "Hellow World!"
    return render(request, 'categorize/index.html', {'form': form})




