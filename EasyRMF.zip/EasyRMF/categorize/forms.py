from django import forms

class CategorizeForm(forms.Form):
    """subject = forms.CharField(max_length=100)
    message = forms.CharField(widget=forms.Textarea)
    sender = forms.EmailField()
    cc_myself = forms.BooleanField(required=False)
    key = forms.CharField(max_length=100)
    newquestion = forms.CharField(max_length=100)
    newquestion_answer = forms.CharField(max_length=100)"""
    information_system_name = forms.CharField(max_length=100)

    
