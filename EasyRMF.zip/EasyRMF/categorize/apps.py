from django.apps import AppConfig


class CategorizeConfig(AppConfig):
    name = 'categorize'
